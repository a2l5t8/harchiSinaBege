# factorial function 
def fact(n) :
    facts = 1
    for i in range(2,n+1) :
        facts*=i
    return facts



# print(fact(1)) => 1
# print(fact(3)) -> 2*3 => 6
# print(fact(6)) -> 6*5*4*3*2 => 720