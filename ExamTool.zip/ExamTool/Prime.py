from math import sqrt
def isPrime(n) :
    state = True
    for i in range(2,int(sqrt(n))+1) :
        if(n%i==0) :
            state = False
            break
    return state

def PrimeRange(n) :
    primes = []
    for i in range(2,int(n)+1) :
        if(isPrime(i)) :
            primes.append(i)
    return primes