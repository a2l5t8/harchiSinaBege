# building a width*height 2D list
def matrixBuilder(width,height , numbers=False) :
    matrix = []
    for i in range(height) :
        line = []
        for j in range(width) :
            # adding numbers start from 1 instead of adding '.' 
            if(numbers) :
                line.append(i*width+j+1)
            else :
                line.append('.')
        matrix.append(line)
    return matrix

# matrix = matrixBuilder(2,4) | matrixBuilder(2,4,numbers=True)
# ['.', '.']     |     [1, 2]
# ['.', '.']     |     [3, 4]
# ['.', '.']     |     [5, 6]
# ['.', '.']     |     [7, 8]


# this function will rotate the whole matrix '90 degree' clockwise
def rotate90(table) :
    table2 = deepcopy(table)
    for i in range(len(table)) :
        for j in range(len(table)) :
            new_j = len(table) - i - 1
            new_i = j
            table2[new_i][new_j] = table[i][j]
    return table2

    
# this function will mirror the whole matrix horizontaly
def horizontal(table) :
    table2 = deepcopy(table)
    for i in range(len(table)) :
        new_i = len(table)-i-1
        table2[new_i] = table[i]
    return table2


# this function will mirror the whole matrix verticaly
def vertical(table) :
    table2 = deepcopy(table)
    for i in range(len(table)) :
        for j in range(len(table)) :
            new_j = len(table) - j - 1
            table2[i][new_j] = table[i][j]
    return table2

