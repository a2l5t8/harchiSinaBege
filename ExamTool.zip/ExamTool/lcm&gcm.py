from math import gcd
def lcm(x,y) :
    return x*y // gcd(x,y)

x , y = map(int,input().split())
print(lcm(x,y) , gcd(x,y)) 