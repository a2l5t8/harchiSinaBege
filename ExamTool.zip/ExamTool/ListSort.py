from copy import deepcopy
def list_sort(lis, key = lambda x: x, max2min = False):
    lis = deepcopy(lis)
    lis2 = []
    for i in range(len(lis)) :
        if not max2min : num = min(lis,key=key)
        else : num = max(lis,key = key)
        lis2.append(num)
        lis.remove(num)
    return lis2

# a = [[1,5,3],[17,46,-34543],[16345,-345,0],[-3453,3564,2]]
# a = list_sort(a,key=lambda x:x[1],max2min=True)
# print(a)